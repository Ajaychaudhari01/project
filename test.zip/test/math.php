<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <title></title>
</head>
<body>


<?php 
class hello
{
   public $x;
   public $y;
   function __construct($a,$b)
   {
      $this->x=$a;
      $this->y=$b;
      $sum=$this->x+this->y;
      echo "$this->x+$this->y =".$sum."<br>";

      $dif=$this->x-this->y;
      echo "$this->x-$this->y =".$dif."<br>";

      $mul=$this->x*this->y;
      echo "$this->x*$this->y =".$mul."<br>";

      $div=$this->x/this->y;
      echo "$this->x+$this->y =".$div."<br>";
   }
}
$obj=new hello(10,5);
?>
</body>
</html>