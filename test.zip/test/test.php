<?php

include('connect.php');
if (isset($_POST['submit']))
{
  $username=$_POST['username'];
  $firstname=$_POST['fname'];
  $lastname=$_POST['lname'];
  $email=$_POST['email'];
  $password=$_POST['password'];
  $gender=$_POST['optradio'];
  $date=$_POST['date'];
  $hobbies= $_POST['myCountry'];
  $qry = "insert into `regtest` (username,firstname,lastname,email,password,gender,date,hobbies) values('$username','$firstname','$lastname','$email','$password','$gender','$date','$hobbies')";
  $res=mysqli_query($con,$qry);
  if($res==TRUE)
  {
    echo '<script>alert("Your data is inserted successfully")</script>';
  } 
  else
  {
    die(mysqli_error($con));
  }
}

?>



<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
</head>  
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<! -- jquery link for validatiion --->
  <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
  <!--------- for show password jquery link  ------------->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <body>
    <div class="container my-3">
      <div class="row m-1">
        <div class="col-md-12">
          <div class="card text-center bg-secondary text-light">
            <div class="card-header bg-warning text-light">
              User Registration Form
            </div>
            <div class="card-body">
              <!-- Form started-->

              <form name="myForm" id="regForm" action="#"  method="post">
               <div class="form-group row m-1">
                <label class="col-sm-2 col-form-label">Username</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="username" placeholder="Enter your Username">
                </div>
              </div>

              <div class="form-group row m-1">
                <label class="col-sm-2 col-form-label">Firstname</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="fname"  placeholder="Enter your firstname">
                </div>
              </div>
              <div class="form-group row m-1">
                <label class="col-sm-2 col-form-label">Lastname</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" name="lname"  placeholder="Enter your Lastname">
                </div>
              </div>

              <div class="form-group row m-1">
                <label  class="col-sm-2 col-form-label">Email</label>
                <div class="col-sm-10">
                  <input type="email" class="form-control" name="email"  placeholder="Enter Your Email">
                </div>
              </div>
              <div class="form-group row m-1">
                <label  class="col-sm-2 col-form-label col-form-label-inline">Password</label>
                <div class="col-sm-10">
                  <input type="password" name="password" id="password" class="form-control"   placeholder="Enter Your Password">
                  <input type="checkbox" id="showPass">Show Password
                </div>
              </div>
              <div class="form-group row m-1">
                <label class="col-sm-2 col-form-label">Confirm Password</label>
                <div class="col-sm-10">
                  <input type="password" class="form-control" name="Cpassword"  placeholder="Confirm Your Password">
                </div>
              </div>

              <!-------- profile uploading   ------------->

                  <div class="form-group row m-1">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Profile Picture</label>
                    <div class="col-sm-10">
                      <input type="file" class="form-control" name="profile" >
                    </div>
                  </div>


                  <div class="form-group row m-1">
                    <label for="inputPassword3" class="col-sm-2 col-form-label">Date</label>
                    <div class="col-sm-10">
                      <input type="date" class="form-control" name="date" >
                    </div>
                  </div>
              <!------ seletct your hobbies  ------------>
              <div class="form-group row m-1">
                <label class="col-sm-2 col-form-label">Hobbies</label>
                <div class="col-sm-10">
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1" />
                    <label class="form-check-label">Sport</label>
                  </div>

                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2" />
                    <label class="form-check-label">Study</label>
                  </div>

                   <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2" />
                    <label class="form-check-label">Social Media</label>
                  </div>

                   <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2" />
                    <label class="form-check-label">Travelling</label>
                  </div>

                   <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2" />
                    <label class="form-check-label">Cooking</label>
                  </div>

                   <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2" />
                    <label class="form-check-label">Garden</label>
                  </div>

                   <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2" />
                    <label class="form-check-label">Art and Craft</label>
                  </div>

                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="option3" />
                    <label class="form-check-label" >Other </label>
                  </div>
                </div>

              <div class="form-group row m-1">
                <label class="col-sm-2 col-form-label">Gender</label>
                <div class="col-sm-10">
                  <div class="row">
                  </div>
                  <div class="col-sm-3">
                    <div class="form-check form-check-inline">

                      <label class="radio-inline">
                        <input type="radio" name="optradio" checked value="male">Male
                      </label>
                      <label class="radio-inline">
                        <input type="radio" name="optradio" value="female" > Female
                      </label>

                    </div>
                    <div class="col-sm-3">
                      <div class="form-check form-check-inline">
                      </div></div>
                    </div>
                  </div>

                  <div class="form-group row m-1">
                    <label  class="col-sm-2 col-form-label">Country</label>
                    <div class="col-sm-10">

                      <select id='myHobbies' name="myCountry">
                        <option name="myCountry">Please seclect your Country
                          <?php
                          $HobbiesArr=array("India","Nepal","America","China","Newslanad","Srilanka","Pakistan","Bangladesh");
                          $arrlen=count($HobbiesArr);
                          for ($i=0;$i<$arrlen;$i++)
                          {
                            echo "<option>$HobbiesArr[$i]</option>";
                          }
                          ?>
                        </option>

                      </select>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-footer bg-warning">

              <div class="row">
                <div class="col-md-6">
                  <button type="submit" class="btn btn-primary" name="submit" id="submit">Submit</button>

                </div>
                <div class="col-md-6">
                 <p>Are you a  registerd user then <a href="logtest.php" class="text-light btn btn-primary ">Login</a> </p>
               </div>

             </div>

           </form>
           <! -- form closed --->

           </div>
         </div>
       </div> 
     </div>
     <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
     <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
     <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
     <script>
    //javascript validation
    $(document).ready(function() {
      $("#regForm").validate({
        errorClass: "error fail-alert",
        validClass: "valid success-alert",
        rules: {
          username : {
            required: true,
            minlength: 3,
            maxlength: 15

          },
          fname : {
            required: true,
            minlength: 3,
            maxlength: 15
          },
          lname : {
            required: true,
            minlength: 3,
            maxlength: 15
          },
          password: {
            required: true,
            minlength: 3,
            maxlength: 15
          },
          Cpassword: {
            required: true,
            minlength: 3,
            maxlength: 15
          },

          email: {
            required: true,
            email: true
          },
          date: {
            required: true,
          },
          myCountry: {
            required: true,
            
          },
        },
        messages : {
          username: {
            minlength: "Name should be at least 3 characters",
            maxlength: "Name should not be at greater than 15 characters"

          },

          fname: {
           minlength: "Name should be at least 3 characters",
           maxlength: "Name should not be at greater than 15 characters"
         },

         lname: {
           minlength: "Name should be at least 3 characters",
           maxlength: "Name should not be at greater than 15 characters"
         },
         password: {
          required: "Please enter your password",
          minlength: "Name should be at least 3 characters",
          maxlength: "Name should not be at greater than 15 characters"
        },
        Cpassword: {
          required: "Please confirm your password",
          minlength: "Name should be at least 3 characters",
          maxlength: "Name should not be at greater than 15 characters"
        },

        email: {
          email: "The email should be in the format: abc@domain.tld"
        },
      }
    });
    });
// show password using jquery
$(document).ready(function(){

 $('#showPass').on('click', function(){
  var passInput=$("#password");
  if(passInput.attr('type')==='password')
  {
    passInput.attr('type','text');
  }else{
   passInput.attr('type','password');
 }
})
})
</script>

</body>
</html>