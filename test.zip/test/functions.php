<?php
echo dirname("/path/reg.php");?>

	