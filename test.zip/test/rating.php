<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        .row{ margin:20px 20px 20px 20px;}
.ratings{ font-size:25px !important;}
.thumbnail img {
    width: 100%;
}
.ratings {
    padding-right: 10px;
    padding-left: 10px;
    color: #d17581;
}
.thumbnail {
    padding: 0;
}
.thumbnail .caption-full {
    padding: 9px;
    color: #333;
}
.glyphicon-thumbs-up:hover{ color:#008000; cursor:pointer;}
.glyphicon-thumbs-down:hover{ color: #E10000; cursor:pointer;}
.counter{ color:#333333;}
.thumbnail img{height:200px;}
    </style>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<h1>hello</h1>
<?php
// Load and initialize post class
require_once 'Post.class.php';
$post = new Post();

if(!empty($_POST['id'])){
    
    // Get post data
    $conditions['where'] = array(
        'id' => $_POST['id']
    );
    $conditions['return_type'] = 'single';
    $postData = $post->getRows($conditions);
    
    // Post total likes
    $postLike = $postData['like_num'];
    
    // Post total dislikes
    $postDislike = $postData['dislike_num'];
    
    // Calculates the numbers of like or dislike
    if($_POST['type'] == 1){
        $like_num = ($postLike + 1);
        $upData = array(
            'like_num' => $like_num
        );
        $return_count = $like_num;
    }else{
        $dislike_num = ($postDislike + 1);
        $upData = array(
            'dislike_num' => $dislike_num
        );
        $return_count = $dislike_num;
    }
    
    // Update post like or dislike
    $condition = array('id' => $_POST['id']);
    $update = $post->update($upData, $condition);
    
    // Return like or dislike number if update is successful, otherwise return error
    echo $update?$return_count:'err';
}
?>
</body>
</html>