 <?php 
 session_start();
 include('fun.php');
$obj=new connections();
$con=$obj->getconnection();
 if (isset($_SESSION['id']) && isset($_SESSION['username'])) {
  $id=$_SESSION['id'];
}
else
{
  header("Location: logtest.php");

}
$qry= "select * from `reg` where id='$id'";
$res=mysqli_query($con,$qry);
$r=mysqli_fetch_array($res);

if($res==TRUE)
{
              //echo '<script>alert("Your data is fetcghed successfully")</script>';
} 
else
{
  die(mysqli_error($con));
}
//data fetch from database and to be shown in table for update

$userQry ="select * from `reg`";
$result = mysqli_query($con, $userQry);
//  echo "<pre>";
// print_r($row);
// die(); 



?>






<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>welcome </title>
  <link
  <!-- Font Awesome -->
  <link
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
  rel="stylesheet"/>
  <!-- Google Fonts -->
  <link
  href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
  rel="stylesheet"
  />
  <!-- MDB -->
  <link
  href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.11.0/mdb.min.css"
  rel="stylesheet"
  />
  <!-- MDB -->
  <script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.11.0/mdb.min.js"
  ></script>
  <style type="text/css">
    table th {
    width: auto !important;
}
  </style>
</head>
<body>


  <!---- navbar for admin panel----->
  <nav class="navbar navbar-expand-lg navbar-light bg-primary">
    <div class="container-fluid">
      <ul class="navbar-nav">
        <!-- Avatar -->
        <li class="nav-item dropdown">
          <a
          class="nav-link dropdown-toggle d-flex align-items-center"
          href="#"
          id="navbarDropdownMenuLink"
          role="button"
          data-mdb-toggle="dropdown"
          aria-expanded="false"
          >
          Welcome :<img src='image/<?php echo $r['picture']?>'  class="rounded-circle text-light" height="22" alt="<?php echo $r['username'];?>" loading="lazy" />
        </a>

        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <li>
            <a class="dropdown-item" href="#">UserId : <th><?php echo $r['id'];?></th></a>
          </li>
          <li>
            <a class="dropdown-item" href="#">Username : <th class="m-1 p-1"><?php echo $r['username'];?></th></a>
          </li>
          <li>
            <a class="dropdown-item bg-danger" href="logout.php?UserId=<?php echo $r['id'];?>">Logout</a>
          </li>
        </ul>
      </li>
    </ul>
  </div>
</nav>
<!------- navbar end -------->

<div class="card">
 <div class="card-header bg-light">
  <table class="table">
    <thead>
      <tr>
        <th scope="col">ID.No</th>
        <th scope="col">Username</th>
               <th scope="col">FirstName</th>
              <th scope="col">LastName</th>
                         <th scope="col">Mobile</th>
            <th scope="col">Email</th>
            <th scope="col">DOB</th>
            <th scope="col">Hobbies</th>
            <th scope="col">Update</th>
            <th scope="col">Delete</th>


          </tr>
        </thead>

      </div>
      <div class="card-body">
        <?php

        while ($s=mysqli_fetch_array($result)) {

          ?>
          <tbody>
            <tr>
              <td scope="row"><?php echo $s['id']?></td>
             

              <td><?php echo $s['username']?></td>
                 <td><?php echo $s['fname']?></td>
                                  <td><?php echo $s['lname']?></td>
                  <td width="1%"> <?php echo $s['mobile']?></td>
                  <td><?php echo $s['email']?></td>
                  <td><?php echo $s['date']?></td>
             
                  <td><?php echo $s['hobbies']?></td>
                  <td class="bg-primary"> 
                    <button type="button" class="btn btn-primary btn-sm" name="update">               
                     <a class="dropdown-item " href="update.php?UserId=<?php echo $s['id'];?>" 
                      name="update">Update</a></button>
                    </td>
                    <td class="bg-danger">               
                      <button type="button" class="btn btn-danger btn-sm" name="delete">  
                       <a class="dropdown-item" href="delete.php?UserId=<?php echo $s['id'];?>">Delete</a>
                     </button>

                   </td>

                 </tr>
               </tbody>
             <?php }  ?>
           </table>

         </div>
         <div class="card-fotoer">

         </div>
       </div>

       <!----- update modal ----->

       <?php 
       if(isset($_POST['update']))
       {
        $userId=$_GET['UserId'];
        $updateQry= "select * from `reg` where id='$userId'";
        $upres=mysqli_connect($con,$updateQry);
        if($upres==true)
        {
          '<script>alert("Your data is fetcghed successfully")</script>';
        }
        else
        {
          die(mysqli_error($con));
        }

      }
      ?>
                </div>
        </div>
      </div>

    </body>
    </html>