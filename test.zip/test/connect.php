<?php 

$con=mysqli_connect('localhost','root','redhat','test1');
if($con==true)
{
//echo "successfully done";
}
else
{
	die(mysqli_error($con));
}



// class connection
// {
// 	public $link;
// 	public function getconnection()
// 	{
// 		$host='localhost';
// 		$user = 'root';
// 		$password='redhat';
// 		$database='test1';
// 		$this->link=mysqli_connect($host,$user,$password,$database);
// 		return $this->link;
// 	}

// 	public function closeconnection()
// 	{
// 		mysqli_close($this->link);
// 	}
// }


?>

