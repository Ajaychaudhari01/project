
<?php
$msg = "";

// If upload button is clicked ...

if (isset($_POST['uploadfile']))
{
  $filesName=array_filter($_FILES['uploadfile']['name']);
  echo $filesName;
  die();
  if(!empty($filesName))
  {
    foreach ($_FILES['uploadfile']['name'] as $key->$val){
      $filename=$_FILES['uploadfile']['name']['$key'];
      $folder="img/.$filename";
  }

  echo $filename;
  $db = mysqli_connect("localhost", "root", "", "test1");

    // Get all the submitted data from the form
    $sql = "INSERT INTO `image` (filename) VALUES ('$filename')";

    // Execute query
    mysqli_query($db, $sql);
    
    // Now let's move the uploaded image into the folder: image
    if (move_uploaded_file($tempname, $folder)) {
      $msg = "Image uploaded successfully";
    }else{
      $msg = "Failed to upload image";
  }
}
}

?>

<!DOCTYPE html>
<html>

<head>
  <title>Image Upload</title>
  <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<! -- jquery link for validatiion --->
</head>

<body>
  <div id="content" class="m-5 p-4">

    <form method="POST" action="" enctype="multipart/form-data">
      <input type="file" name="uploadfile[]" multiple value="" />

      <div>
        <button type="submit"
            name="upload">
        UPLOAD
        </button>
      </div>
    </form>
  </div>
</body>

</html>
