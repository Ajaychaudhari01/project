<?php

define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASSWORD','');
define('DB_DATABASE','test1');

class DatabaseConnection
{
    public function __construct()
    {
//
    }
    public function connections()
    {
        $conn = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_DATABASE);

        if($conn->connect_error)
        {
            die ("<h1>Database Connection Failed</h1>");
        }
        else
        {
        echo "Database Connected Successfully";
        return $this->conn = $conn;
    }
    }
}

$obj=new DatabaseConnection();
$con=$obj->connections();
?>
