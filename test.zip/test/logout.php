<?php 

session_start();

session_unset();

session_destroy();

header("Location: logtest.php");

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>logout</title>
</head>
<body>
hii your r successfully logout !!!!
</body>
</html>