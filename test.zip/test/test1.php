<?php
include('connect.php');
//$qry=SELECT  * from student_address INNER JOIN student_marks on student_address.sid=student_marks.sid;
$qry = "SELECT * from `reg` LEFT JOIN `regtest` on reg.fname=regtest.firstname";
$res=mysqli_query($con,$qry);

echo "<pre>";
print_r($res);


echo "<table>
<tr>
<th>Username</th>
<th>Firstname</th>
<th>Lastname</th>
<th>Email</th>
<th>Gender</th>
<th>Date</th>
<th>Hobbies</th>

</tr>";
while($row = mysqli_fetch_array($res)) {
  echo "<tr>";
    echo "<td>" . $row['username'] . "</td>";
  echo "<td>" . $row['firstname'] . "</td>";
  echo "<td>" . $row['lastname'] . "</td>";
  echo "<td>" . $row['email'] . "</td>";
  echo "<td>" . $row['gender'] . "</td>";
  echo "<td>" . $row['date'] . "</td>";
    echo "<td>" . $row['hobbies'] . "</td>";

  echo "</tr>";
}
echo "</table>"
?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
</head>  
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<! -- jquery link for validatiion --->
  <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
  <!--------- for show password jquery link  ------------->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <style>
table {
  width: 100%;
  border-collapse: collapse;
}

table, td, th {
  border: 1px solid black;
  padding: 5px;
}

th {text-align: left;}
</style>
  <body>

<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
     <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
     <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
     <script>


</html>
<?php // destroy the session




?>