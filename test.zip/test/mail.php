
   
   <head>
      <title>Sending HTML email using PHP</title>
   </head>
    
   <body>
      
      

<?php
$to = "somebody@example.com";
$subject = "My subject";
$txt = "Hello world!";
$headers = "From: titrajeussoissoi-1263@yopmail.com" . "\r\n" ;

mail($to,$subject,$txt,$headers);
?>


      
   </body>
</html>
