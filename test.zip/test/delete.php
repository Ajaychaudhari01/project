<?php
include('fun.php');
$obj=new connections();
$con=$obj->getconnection();
$id=$_GET['UserId'];
$qry= "DELETE FROM `reg` WHERE  id='$id'";

$delres=mysqli_query($con,$qry);
if($delres== TRUE)
{
  header('location:welcome.php');
  
}

else
{
  echo "data not delete";
}

?>

/*
if(isset($_GET['deleteId']))
{
  $id=$_GET['deleteId'];
  Deletedata($connections,$id);
}
// 
function delete_data($connections,$id)
{

  $qry= "DELETE FROM `reg` WHERE  id='$id'";

$delres=mysqli_query($con,$qry);
if($delres== TRUE)
{
  header('location:welcome.php');
  
}

else
{
  echo "data not delete";
}

  
}

var Deletedata = function(id) {
  $.ajax({
    type:"GET",
    url="delete.php",
    data:{deleteId:id},
    dataType:"html",
    success: function(data){
      $('msg').html(data);
      $('#table-container').load('welcome.php');
    }
  });
}; 
*/