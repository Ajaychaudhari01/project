<?php 

$con=mysqli_connect('localhost','root','redhat','test1');
if($con==true)
{
echo "successfully done";
}
else
{
	die(mysqli_error($con));
}



?>