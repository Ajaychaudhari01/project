<?php

include('db.php');
$obj=new DatabaseConnection();
$con=$obj->connections();

if (isset($_POST['submit']))
{
  $password=$_POST['password'];
    $username=$_POST['username'];
  // $qry = "insert into `logtest` (username,email,password) values('$username','$email','$password')";
  $qry = "select * from reg where username='$username' AND password='$password' ";


  $result = mysqli_query($con, $qry);
  if (mysqli_num_rows($result) === 1) {
    $row = mysqli_fetch_assoc($result);
    if ($row['username'] === $username && $row['password'] === $password) 
    {
      $_SESSION['username'] = $row['username'];
      $_SESSION['username'] = $row['username'];
      $_SESSION['id'] = $row['id'];
      header("Location: welcome.php");
      exit();
    }
    else
    {
      header("Location: logtest.php?error=Incorect User name or password");
      exit();
    }

  }
}
?>



<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
</head>  
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<! -- jquery link for validatiion --->
  <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
  <!--------- for show password jquery link  ------------->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <body>

    <section>
      <div class="container my-3">
        <div class="row m-5">
          <div class="col-md-12">
            <div class="card text-center bg-secondary text-light">
              <div class="card-header bg-warning">
                Login Form
              </div>
              <div class="card-body">
                <!-- Form started-->

                <form name="myForm" id="regForm" action="#"  method="post">
                 <div class="form-group row m-1">
                  <label class="col-sm-2 col-form-label">Username</label>
                  <div class="col-sm-10">
                    <input type="text" class="form-control" name="username" placeholder="Enter your Username">
                  </div>
                </div>

              
                  <div class="form-group row m-1">
                    <label  class="col-sm-2 col-form-label">Password</label>
                    <div class="col-sm-10">
                      <input type="password" name="password" id="password" class="form-control"   placeholder="Enter Your Password">
                      <input type="checkbox" id="showPass">Show Password
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-footer bg-warning">

              <div class="row">
                <div class="col-sm-6">
                  <button type="submit" class="btn btn-primary" name="submit" id="submit">Submit</button>

                </div>
                <div class="col-sm-6">
                 <p>You are not a registerd user then <a href="reg.php" class="text-light btn btn-primary ">Sign Up</a> </p>
               </div>

             </div>

           </form>
           <! -- form closed --->

           </div>
         </div>
       </div> 
     </div>
   </section>
   <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
   <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
   <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
   <script>
    //javascript validation
    $(document).ready(function() {
      $("#regForm").validate({
        errorClass: "error fail-alert",
        validClass: "valid success-alert",
        rules: {
          username : {
            required: true,
            minlength: 3,
            maxlength: 15

          },
          
          password: {
            required: true,
            minlength: 3,
            maxlength: 15
          },


          email: {
            required: true,
            email: true
          },
        },
        messages : {
          username: {
            minlength: "Name should be at least 3 characters",
            maxlength: "Name should not be at greater than 15 characters"

          },

          password: {
            required: "Please enter your password",
            minlength: "Name should be at least 3 characters",
            maxlength: "Name should not be at greater than 15 characters"
          },

          email: {
            email: "The email should be in the format: abc@domain.tld"
          },
        }
      });
    });
// show password using jquery
$(document).ready(function(){

 $('#showPass').on('click', function(){
  var passInput=$("#password");
  if(passInput.attr('type')==='password')
  {
    passInput.attr('type','text');
  }else{
   passInput.attr('type','password');
 }
})
})
</script>

</body>
</html>