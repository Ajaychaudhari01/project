<!DOCTYPE html>
<html>
<head>
    <title></title>
    <style type="text/css">
        .row{ margin:20px 20px 20px 20px;}
.ratings{ font-size:25px !important;}
.thumbnail img {
    width: 100%;
}
.ratings {
    padding-right: 10px;
    padding-left: 10px;
    color: #d17581;
}
.thumbnail {
    padding: 0;
}
.thumbnail .caption-full {
    padding: 9px;
    color: #333;
}
.glyphicon-thumbs-up:hover{ color:#008000; cursor:pointer;}
.glyphicon-thumbs-down:hover{ color: #E10000; cursor:pointer;}
.counter{ color:#333333;}
.thumbnail img{height:200px;}
    </style>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<h1>hhkkfla</h1>

<?php
// Load and initialize post class
require_once 'Post.class.php';
$post = new Post();

// Get posts data
$posts = $post->getRows();
?>

<div class="row">
    <?php if(!empty($posts)){ foreach($posts as $row){ ?>
    <div class="col-sm-4 col-lg-4 col-md-4">
        <div class="thumbnail">
            <img src="<?php echo 'images/'.$row['image']; ?>" />
            <div class="caption">
                <h4><?php echo $row['title']; ?></h4>
                <p><?php echo $row['content']; ?></p>
            </div>
            <div class="ratings">
                <p class="pull-right"></p>
                <p>
                    <!-- Like button -->
                    <span class="glyphicon glyphicon-thumbs-up" onClick="cwRating(<?php echo $row['id']; ?>, 1, 'like_count<?php echo $row['id']; ?>')"></span>&nbsp;
                    <!-- Like counter -->
                    <span class="counter" id="like_count<?php echo $row['id']; ?>"><?php echo $row['like_num']; ?></span>&nbsp;&nbsp;&nbsp;
                    
                    <!-- Dislike button -->
                    <span class="glyphicon glyphicon-thumbs-down" onClick="cwRating(<?php echo $row['id']; ?>, 0, 'dislike_count<?php echo $row['id']; ?>')"></span>&nbsp;
                    <!-- Dislike counter -->
                    <span class="counter" id="dislike_count<?php echo $row['id']; ?>"><?php echo $row['dislike_num']; ?></span>
                </p>
            </div>
        </div>
    </div>
    <?php } } ?>
</div>
</body>
</html>