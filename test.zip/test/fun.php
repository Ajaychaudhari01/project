<?php 
//connection function 

class connections
{
  public $link;
  public function getconnection()
  {
    $host='localhost';
    $user = 'root';
    $password='redhat';
    $database='crud';
    $this->link=mysqli_connect($host,$user,$password,$database);
    return $this->link;
  }

   public function dbclose()
   {
     mysqli_close($this->link);
   }
}




//data insertion function
class InsertData
{
  public $username,$firstname,$lastname,$mobile,$email,$password,$gender,$date,$country,$filename,$HobbiesChk;
  public function regUsers()
  {

$obj=new connections();
$con=$obj->getconnection();        
  $qry = "insert into `reg` (username,fname,lname,mobile,email,password,gender,date,country,picture,hobbies) values('$this->username','$this->firstname','$this->lastname','$this->mobile','$this->email','$this->password','$this->gender','$this->date','$this->country','$this->filename','$this->HobbiesChk')";
    $res=mysqli_query($con,$qry);
    print_r($res);
      if (mysqli_affected_rows($con) == 1) {
        $obj->dbclose();
        echo 'data inserted';
        return true;
      }
      else{
        $obj->dbclose();
        echo 'data not inserted';
        return false;
      }

    }
  }

  // login user function
  class userLog
  {
    public $username,$password;

    public function loginUser(){
      $obj=new connections();
      $con=$obj->getconnection(); 
      $qry = "select * from reg where username='$this->username' AND password='$this->password' ";
      $result=mysqli_query($con,$qry);
      if (mysqli_num_rows($result) === 1) {
    $row = mysqli_fetch_assoc($result);

    if ($row['username'] === $this->username && $row['password'] === $this->password) 
    {
      $_SESSION['username'] = $row['username'];
      $_SESSION['username'] = $row['username'];
      $_SESSION['id'] = $row['id'];
      header("Location: welcome.php");
      exit();
    }
    else
    {
      header("Location: logtest.php?error=Incorect User name or password");
      exit();
    }

  }
    }
  }
?>
