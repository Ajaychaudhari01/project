<?php
include('fun.php');
$obj=new connections();
$con=$obj->getconnection();
$id=$_GET['UserId'];
$qry= "select * from `reg` where id='$id'";
$upres=mysqli_query($con,$qry);
$s=mysqli_fetch_array($upres);

if (isset($_POST['update']))
{
  $username=$_POST['username'];
  $firstname=$_POST['fname'];
  $lastname=$_POST['lname'];
  $mobile=$_POST['mobile'];
  $email=$_POST['email'];
  $gender=$_POST['gender'];
  $password=$_POST['password'];
  $date=$_POST['date'];
  // // file uploding code
  // $filename = $_FILES["uploadfile"]["name"];
  // $tempname = $_FILES["uploadfile"]["tmp_name"];  
  // $folder = "image/".$filename;
  $sql = "UPDATE `reg` SET username='".$username."', fname='".$firstname."', lname='".$lastname."', mobile='".$mobile."', password='".$password."',gender='".$gender."' , date='".$date."' , email='".$email."' WHERE id='".$_GET['UserId']."'";

  $res=mysqli_query($con,$sql);
  if($res==TRUE)
  {
    header('location:welcome.php');
  } 
  else
  {
    die(mysqli_error($con));
  }
}

?>


 
<!DOCTYPE html>
<html>
<head>
  <title>Welcome</title>
  <style type="text/css">
    label.error.fail-alert {
border: 2px solid red;
border-radius: 4px;
line-height: 1;
padding: 2px 0 6px 6px;
background: #ffe6eb;
}
input.valid.success-alert {
border: 2px solid #4CAF50;
color: green;
}

  </style>
</head>  
<!-- CSS only---> 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<! -- jquery link for validatiion --->
  <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
  <!--------- for show password jquery link  ------------->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<body class="bg-teal text-light">

  <div class="container">
    <form name="upForm" class="m-3 p-3" id="upForm"  enctype="multipart/form-data" method="post">


      <table class="table table-striped">
  <tbody>
    <tr>
      <div class="form-group row m-1">
      <td>  <label class="col-sm-2 col-form-label">User Id.</label></td>
        <td><div class="col-sm-10">
          <input type="text" class="form-control" name="userId" value="<?php  echo ($s['id']); ?>">
        </div>
      </td>
          </div>
        </tr>
<tr>
      <div class="form-group row m-1">
      <td>  <label class="col-sm-2 col-form-label">Username</label></td>
      <td/>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="username" value="<?php  echo ($s['username']); ?>">
        </div> </td>
      </div>
</tr>
<tr>
      <div class="form-group row m-1">
      <td>  <label class="col-sm-2 col-form-label">Firstname</label></td>
        <td><div class="col-sm-10">
          <input type="text" class="form-control" name="fname" value="<?php  echo ($s['fname']); ?>">
        </div></td>
      </div>
</tr>
<tr>
      <div class="form-group row m-1">
        <td><label class="col-sm-2 col-form-label">Lastname</label></td>
        <td><div class="col-sm-10">
          <input type="text" class="form-control" name="lname" value="<?php  echo ($s['lname']); ?>">
        </div></td>
      </div>

</tr>
<tr>
      <div class="form-group row m-1">
        <td><label class="col-sm-2 col-form-label">Password</label></td>
        <td><div class="col-sm-10">
          <input type="text" class="form-control" name="password" value="<?php  echo ($s['password']); ?>">
        </div></td>
      </div>
      </tr>
<tr>
      <div class="form-group row m-1">
        <td><label class="col-sm-2 col-form-label">Mobile</label></td>
        <td><div class="col-sm-10">
          <input type="text" class="form-control" name="mobile" value="<?php  echo ($s['mobile']); ?>">
        </div></td>
      </div> 
</tr>
<tr>
      <div class="form-group row m-1">
        <td><label class="col-sm-2 col-form-label">Email</label></td>
        <td><div class="col-sm-10">
          <input type="text" class="form-control" name="email" value="<?php  echo ($s['email']); ?>">
        </div></td>
      </div>

</tr>
<tr>
      <div class="form-group row m-1">
        <td><label class="col-sm-2 col-form-label">Hobbies</label></td>
        <td><div class="col-sm-10">
          <input type="text" class="form-control" name="hobbies" value="<?php  echo ($s['hobbies']); ?>">
        </div></td>
      </div>
</tr>
<tr>
      <div class="form-group row m-1">
        <td><label class="col-sm-2 col-form-label">Gender</label></td>
        <td><div class="col-sm-10">
          <input type="text" class="form-control" name="gender" value="<?php  echo ($s['gender']); ?>">
        </div></td>
      </div>
</tr>
<tr>

      <div class="form-group row m-1">
        <td><label class="col-sm-2 col-form-label">DOB</label></td>
        <td><div class="col-sm-10">
          <input type="date" class="form-control" name="date" value="<?php  echo ($s['date']); ?>">
        </div></td>
      </div>
</tr>
<td>
      <div class="form-group row m-1">
        <button type="submit" class="btn btn-primary" name="update" id="update">Update</button>
      </div></td>
  </tbody>
</table>
    </form>

    <! -- form closed --->

    </div>
  </body>

     <script>
    //javascript validation
    $(document).ready(function() {
      $("#upForm").validate({
        errorClass: "error fail-alert",
        validClass: "valid success-alert",
        rules: {
          username : {
            required: true,
            minlength: 3,
            maxlength: 15

          },
          fname : {
            required: true,
            minlength: 3,
            maxlength: 15
          },
          lname : {
            required: true,
            minlength: 3,
            maxlength: 15
          },
          password: {
            required: true,
            minlength: 3,
            maxlength: 15
          },
          Cpassword: {
            required: true,
            minlength: 3,
            maxlength: 15
          },

             mobile: {
            required: true,
            minlength: 10,
            maxlength: 13
          },

          email: {
            required: true,
            email: true
          },
          date: {
            required: true,
          },
          myCountry: {
            required: true,
            
          },
        },
        messages : {
          username: {
            minlength: "Name should be at least 3 characters",
            maxlength: "Name should not be at greater than 15 characters"

          },

          fname: {
           minlength: "Name should be at least 3 characters",
           maxlength: "Name should not be at greater than 15 characters"
         },

         lname: {
           minlength: "Name should be at least 3 characters",
           maxlength: "Name should not be at greater than 15 characters"
         },
         password: {
          required: "Please enter your password",
          minlength: "Name should be at least 3 characters",
          maxlength: "Name should not be at greater than 15 characters"
        },
        Cpassword: {
          required: "Please confirm your password",
          minlength: "Name should be at least 3 characters",
          maxlength: "Name should not be at greater than 15 characters"
        },

        mobile: {
           minlength: "Mobile number should be at least 10 characters",
           maxlength: "mobile number should not be at greater than 13 characters"
         },

        email: {
          email: "The email should be in the format: abc@domain.tld"
        },
      }
    });
    });
// show password using jquery
$(document).ready(function(){

 $('#showPass').on('click', function(){
  var passInput=$("#password");
  if(passInput.attr('type')==='password')
  {
    passInput.attr('type','text');
  }else{
   passInput.attr('type','password');
 }
})
})
</script>


     <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
     <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
     <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
     
  </html>