<?php
include('connect.php');
if (isset($_POST['username']) && $_POST['username'] && isset($_POST['password']) && $_POST['password']) {
    $password=$_POST['password'];
    $username=$_POST['username'];
  // $qry = "insert into `logtest` (username,email,password) values('$username','$email','$password')";
  $qry = "select * from reg where username='$username' AND password='$password' ";
 $result = mysqli_query($con, $qry);
  if (mysqli_num_rows($result) === 1) {
    echo json_encode(array('success' => 1));
} else {
    echo json_encode(array('success' => 0));
}

}
?>
