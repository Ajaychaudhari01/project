<?php

$data=stripslashes(file_get_contents("php://input"));
$mydata=json_decode($data,true);
$id= $mydata['id'];
echo "hello chacha";


// if(isset($mydata['id'])){

//   global $wpdb;
//   global $table_prefix;
//   $table = $table_prefix.'friendReq';
//   $data = array(
// 	'requestFromId' => 2,
// 	'requestToId'    => $mydata['id'],
// 	'requestStatus' =>"pending",
// 	'requestNotifictaionStatus' => "No",
	  
// );
// $format = array(
// 	'%s',
// 	'%s'
// );
// $success=$wpdb->insert( $table, $data, $format );
// 	if($success){
// 		echo "thanks brohter";
// 	}else{
// 		echo "kya dekh rha hai re cc";
// 	}

// }

if(isset($mydata['id'])){

    global $wpdb;
    global $table_prefix;
    $table = $table_prefix.'friendReq';
      $requestFromId = 2;
      $requestToId = $mydata['id'];
      $requestStatus = "pending";
      $requestNotifictaionStatus = "No";
    
      $sql= $wpdb->prepare("insert into $table (requestFromId,requestToId,requestStatus,requestNotifictaionStatus)
       values('2','$requestToId','$requestStatus','$requestNotifictaionStatus')");
       print_r($sql);
      $result = $wpdb->query($sql);
      if($result){
          echo "thanks brohter send";
      }else{
          echo "kya dekh rha hai re bsdk";
      }
  
  }
  
?>