<?php
    $username = 'ajay';
 $password =123;
//if(!empty($_POST['username'] && $_POST['password']))
{
    //$username = $_POST['username'];
    $username = 'ajay';
    //$password = $_POST['password'];
    global $wpdb;
global $table_prefix;
$table = $table_prefix.'Blog';
$qry= "select * from $table where username='$username'";
$res=$wpdb->prepare($qry);
$result= $wpdb->get_results($res);
$array = json_decode(json_encode($result), true);
foreach ($array as $ar) { 

?>
<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<!-- Font Awesome -->
		<link
		href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
		rel="stylesheet"
		/>
		<!-- Google Fonts -->
		<link
		href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
		rel="stylesheet"
		/>
		<!-- MDB -->
		<link
		href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.0.0/mdb.min.css"
		rel="stylesheet"
		/>
	</head>
	<body>
		<!-- Navbar-->
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<div class="container-fluid justify-content-between">
				<!-- Left elements -->
				<div class="d-flex">
					<!-- Brand -->
					<a class="navbar-brand me-2 mb-1 d-flex align-items-center" href="#">
						<img
						src="https://mdbcdn.b-cdn.net/img/logo/mdb-transaprent-noshadows.webp"
						height="20"
						alt="MDB Logo"
						loading="lazy"
						style="margin-top: 2px;"
						/>
					</a>

					<!-- Search form -->
					<form class="input-group w-auto my-auto d-none d-sm-flex " method="post">

						<span class="input-group-text border-0 d-none d-lg-flex"  type="submit">
							<input id="search" name="search" type="search" placeholder="Type here" >
							<a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample"> search  </a>
						</span>

					</form>
				</div>
				<!-- Left elements -->

				<!-- Center elements -->
				<ul class="navbar-nav flex-row d-none d-md-flex">
					<li class="nav-item me-3 me-lg-1 active">
						<a class="nav-link" href="#">
							<span><i class="fas fa-home fa-lg"></i></span>
							<span class="badge rounded-pill badge-notification bg-danger">1</span>
						</a>
					</li>


					<li class="nav-item me-3 me-lg-1">
						<a class="nav-link" data-mdb-toggle="modal" data-mdb-target="#friendRequest" href="#">
							<span><i class="fas fa-users fa-lg"></i></span>
							<span class="badge rounded-pill badge-notification bg-danger">2</span>
						</a>
					</li>
				</ul>
				<!-- Center elements -->

				<!-- Right elements -->
				<ul class="navbar-nav flex-row">
					<li class="nav-item me-3 me-lg-1">
						<a class="nav-link d-sm-flex align-items-sm-center" data-toggle="collapse" href="#profile" role="button" aria-expanded="false" aria-controls="profile">
							<img
							src="https://mdbcdn.b-cdn.net/img/new/avatars/1.webp"
							class="rounded-circle"
							height="22"
							alt=""
							loading="lazy"
							/>
							<strong class="d-none d-sm-block ms-1"><span >Welcome </span><?php echo $ar['username']?></strong>
						</a>

					</li>
					<li class="nav-item me-3 me-lg-1">
						<a class="nav-link" href="#">
							<span><i class="fas fa-plus-circle fa-lg"></i></span>
						</a>
					</li>
					<li class="nav-item dropdown me-3 me-lg-1">
						<a
						class="nav-link dropdown-toggle hidden-arrow"
						href="#"
						id="navbarDropdownMenuLink"
						role="button"
						data-mdb-toggle="dropdown"
						aria-expanded="false"
						>
						<i class="fas fa-comments fa-lg"></i>

						<span class="badge rounded-pill badge-notification bg-danger">6</span>
					</a>
					<ul
					class="dropdown-menu dropdown-menu-end"
					aria-labelledby="navbarDropdownMenuLink"
					>
					<li>
						<a class="dropdown-item" href="#">Some news</a>
					</li>
					<li>
						<a class="dropdown-item" href="#">Another news</a>
					</li>
					<li>
						<a class="dropdown-item" href="#">Something else here</a>
					</li>
				</ul>
			</li>
		</ul>
		<!-- Right elements -->
	</div>
</nav>
<!-- Navbar -->
<?php }}


// else{
//     $url = admin_url('admin.php?page=blog');
// 	echo "<script>window.location.href='$url';</script>";
// }

?>

<!-- serch bar started here  -->

<!-- search friend started here  -->

<div class="collapse" id="collapseExample">
	<div class="card card-body">
		<table class="table align-middle mt-5 mb-0 bg-white">
			<tbody>
				<?php								
										//searchbar start
				global $wpdb;
				$username = $_POST['search'];
				$qry= "select * from `wp_Blog` where username='$username'";
				$res=$wpdb->prepare($qry);
				$result= $wpdb->get_results($res);
				$array = json_decode(json_encode($result), true);
				foreach ($array as $arr ) { ?>
					<tr>
						<td>
							<div class="d-flex align-items-center">
								<img src="https://mdbootstrap.com/img/new/avatars/8.jpg" alt=""
								style="width: 45px; height: 45px"
								class="rounded-circle"/>
								<div class="ms-3">
									<p class="fw-bold mb-1"><?php echo $arr['username'] ; ?></p>
								</div>
							</div>
						</td>
						<td name="friendreq" id="friendreq">
							<button type="button" class="btn btn-link btn-sm btn-rounded bg-success text-center text-white friendreq" value="<?php echo $arr['id'] ; ?>">
                            <?php echo $arr['id'] ; ?>Send Request
                            <p id="logUserId" class="logUserId" value="<?php echo $ar['id']; ?>"><?php echo $ar['id']; ?></p>
							</button>
						</td>
						<td>
							<button type="button" class="btn btn-link btn-sm btn-rounded bg-success text-center text-white">
								Cancel
							</button>
						</td>
					</tr>
				<?php } ?>
			</tbody>
		</table>

	</div>
</div>



<!-- earch ended here  -->

<!-- profile code started here  -->

<div class="collapse" id="profile">

	<section>
		<div class="container-fluid">
			<div class="row mt-5">
				<h1 class="text-center">Welcome !!</h1>
				<div class="col-md-4 bg-success">
					<table class="table align-middle mb-0 bg-white">
						<thead class="bg-light">
							<tr>
								<td>
									<div class="d-flex align-items-center">
										<img
										src="<?php echo $ar['picture']?>"
										alt="sorry "
										style="width: 100px; height: 100px"
										class="rounded-circle"
										/>
										<div class="ms-3" name="tbody">
											<p class="fw-bold mb-1 logUserid" value="<?php echo $ar['id']?>"><?php echo $ar['id']?></p>
											<p class="fw-bold mb-1"><?php echo $ar['username']?></p>
											<p class="text-muted mb-0"><?php echo $ar['email']?></p>
										</div>
									</div>
								</td>

							</tr>
						</thead>
					</table>

				</div>
				<div class="col-md-8 bg-danger">
					<table class="table align-middle mb-0 bg-white">
						<thead class="bg-light">
							<tr>
								<th>Username</th>
								<th><?php echo $ar['username']?></th>
							</tr>
						</tr>
						<tr>
							<th>First Name</th>
							<th><?php echo $ar['fname']?></th>
						</tr>
						<tr>
							<th>Last Name</th>
							<th><?php echo $ar['lname']?></th>
						</tr>
						<tr>
							<th>Email</th>
							<th><?php echo $ar['email']?></th>
						</tr>
						<tr>
							<th>DOb</th>
							<th><?php echo $ar['dob']?></th>
						</tr>
						<tr>
							<th>Phone</th>
							<th><?php echo $ar['phone']?></th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>
</section>
                </div>
                
<!-- profile code wnded here  -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

logUserid
<script>
  $(document).ready(function(){
     // alert(1111);
     $(document).on("click","friendreq",function(){
        let stid=$(".logUserId").val();
    console.log(stid);
    stid= JSON.stringify(stid);
    alert(stid);

   });
$("tbody").on("click", ".friendreq", function(){
	console.log("request send button clicked");
	let id=$(this).val();
       let mydata={id:id};
    //mydata= JSON.stringify(mydata);
            $.ajax({
                url:"../wp-content/plugins/blog/friendreq.php",
            method:"POST",
	data:JSON.stringify(mydata),
            success:function(data){
                console.log(data);
            },
        });

      });
  })

</script>

</body>
</html>