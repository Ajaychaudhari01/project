<?php

add_action('admin_menu','remove_pages');
function remove_pages()
{
  remove_menu_page('crud.php');
}

?>