

<?php 
global $wpdb;
global $table_prefix;
$table = $table_prefix.'Crud_data';

$action = isset($_GET['action']) ? trim($_GET['action']) : "";

$id = isset($_GET['id']) ? intval($_GET['id']) : "";
$row_details = $wpdb->get_row(
	$wpdb->prepare(
		"select * from $table where id =%d",$id),ARRAY_A

);



?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- Font Awesome -->
	<link
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
	rel="stylesheet"
	/>
	<!-- Google Fonts -->
	<link
	href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
	rel="stylesheet"
	/>
	<!-- MDB -->
	<link
	href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.0.0/mdb.min.css"
	rel="stylesheet"
	/>
	<style type="text/css">
		.error {
			color: red;
			background-color: #010111;

			body {
				background-image: url("3.jpg");
				background-repeat: no-repeat;
				background-color: #cccccc;
			}

		</style>

	</style>
</head>
<body>

	<h1 class="bg-dark text-white mt-2">Welcome <span class="text-danger"><?php print_r($row_details['username']);?></span> Here you can update your details....</h1>
	<section>
		<div class="container">
			<div class="row mt-5">
				<div class="col-md-3"></div>
				<div class="col-md-6 bg-light">
					
					<form method="post" id="updateBtn" action="admin.php?page=Update&action=Update&id=<?php echo $id ;?>">
						<div class="form-group">
							<label for="exampleFormControlInput1">UserName</label>
							<input type="text" class="form-control" name="username" value="<?php echo ($row_details['username'])?>">
						</div>

						<div class="form-group">
							<label for="exampleFormControlInput1">Email address</label>
							<input type="text" class="form-control" name="email" value="<?php echo ($row_details['email'])?>">
						</div>

						<div class="form-group">
							<label for="exampleFormControlInput1">Password </label>
							<input type="text" class="form-control" name="password" value="<?php echo ($row_details['password'])?>">
						</div>

						<div class="form-group">
							<label for="exampleFormControlInput1">Phone </label>
							<input type="text" class="form-control" name="phone" value="<?php echo ($row_details['phone'])?>">
						</div>
						
						<button type="submit" name="submit" class="btn btn-primary btn-block">Update</button>
					</form>
				</div>
				<div class="col-md-3"></div>
			</div>
		</div>
	</div>
</section>



</body>
</html>


<?php
if (isset($_POST['submit']))
{
	if (!empty($action)) {
		global $wpdb;
		global $table_prefix;
		$table = $table_prefix.'Crud_data';
		$success=$wpdb->update( $table,array(
			'username' => $_POST['username'],
			'email'    => $_POST['email'],
			'password' => $_POST['password'],
			'phone'    => $_POST['phone']
		),array('id' =>$id),
	);
		if($success){
		$url = admin_url('admin.php?page=crud');
		echo "<script>window.location.href='$url';</script>";
		}
		else{
			echo "data not updated ";
		}
	}
}




?>

<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
<script>
    //javascript validation
    $(document).ready(function() {
    	$("#updateBtn").validate({
    		errorClass: "error fail-alert",
    		validClass: "valid success-alert",
    		rules: {
    			username : {
    				required: true,
    				minlength: 3,
    				maxlength: 15

    			},
    			password: {
    				required: true,
    				minlength: 3,
    				maxlength: 15
    			},
    			phone: {
    				required: true,
    				minlength: 10,
    				maxlength: 13
    			},

    			email: {
    				required: true,
    				email: true
    			},
    		},
    		messages : {
    			username: {
    				minlength: "Name should be at least 3 characters",
    				maxlength: "Name should not be at greater than 15 characters"

    			},
    			password: {
    				required: "Please enter your password",
    				minlength: "Password should be at least 3 characters",
    				maxlength: "Password should not be at greater than 15 characters"
    			},
    			mobile: {
    				minlength: "Mobile number should be at least 10 characters",
    				maxlength: "Mobile number should not be at greater than 13 characters"
    			},
    			
    			email: {
    				email: "The email should be in the format: abc@domain.tld"
    			},
    		}
    	});
      //
      function nospaces(t){
      	if(t.value.match(/\s/g)){
      		t.value=t.value.replace(/\s/g,'');
      	}
      }

//for disbaling space entry in i nput fields 
$('input').keypress(function(e)
{
	if(e.which === 32)
		return false;
});

});



// //radio button validation 
//
</script>


