<?php
/*
Plugin Name: crud
Plugin URI: https://github.com/Ajaychaudhari01/
Description: Just another contact form plugin. Simple but flexible.
Author: Ajay Chaudhari
Author URI : https://github.com/Ajaychaudhari01/
Version: 1.0
*/

//link for custom curd opertions in wordpress........
//https://phpcoder.tech/how-to-create-plugin-in-wordpress-with-example/
// hook for pulgin activate/ deactivate
register_activation_hook(__FILE__,'curd_data_activate');

register_deactivation_hook(__FILE__,'curd_data_deactivate');



//function for form activation 
function curd_data_activate()
{
	global $wpdb;
	global $table_prefix;
	$table=$table_prefix.'Crud_data';
	$sql="CREATE TABLE $table (
	id int NOT NULL AUTO_INCREMENT,
	username varchar(255) NOT NULL,
	password varchar(255) NOT NULL,
	email varchar(255) NOT NULL,
	phone varchar(255) NOT NULL,
	PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;";

$wpdb->query($sql);

}


//function for form deactivation 
function curd_data_deactivate()
{
	global $wpdb;
	global $table_prefix;
	$table=$table_prefix.'Crud_data';
	$sql="DROP TABLE $table";
	$wpdb->query($sql);
}


add_action('admin_menu','curd_data_menu');

add_action('admin_menu','remove_pages');
function remove_pages()
{
    remove_submenu_page('crud','hello');
}


function curd_data_menu()
{
	  add_menu_page('list', //page title
        'simple Crud', //menu title
        'manage_options', //capabilities
        'crud', //menu slug
        curd_data_list //function
    );
	  add_submenu_page('crud',//parent page slug
        'insert',//page title
        'Insert',//menu titel
        'manage_options',//manage optios
        'Insert',//slug
        crud_data_insert//function
    );
	  	   add_submenu_page('crud',//parent page slug
        'update',//$page_title
        ' Update',// $menu_title
        'manage_options',// $capability
        'Update',// $menu_slug,
        crud_data_update// $function
    );
    add_submenu_page('crud',//parent page slug
        'delete',//$page_title
        ' Delete',// $menu_title
        'manage_options',// $capability
        'Delete',// $menu_slug,
        crud_data_delete// $function
    );
    add_submenu_page('crud',//parent page slug
        'hello',//$page_title
        ' hello',// $menu_title
        'manage_options',// $capability
        'hello',// $menu_slug,
        crud_data_hello// $function
    );


}

//for data list show 
function curd_data_list(){
	include('crudDataList.php');
}


//for data insert in table 
function crud_data_insert()
{
	include('crudDataInsert.php');
}
//for delete the data 
function crud_data_delete()
{
	include('crudDatadelete.php');
}
function crud_data_update()
{
	include('crudupdateData.php');
}
function crud_data_hello()
{
    include('hello.php');
}








?>