<?php 
/**
 * Uninstall all curd.
 *
 */

register_uninstall_hook(__FILE__, 'plugin_deleted');// drop a custom database table
function plugin_deleted($value='')
{
	echo "hello";
global $wpdb;
 global $table_prefix;
 $table=$table_prefix.'Crud_data';
$wpdb->query("DROP TABLE IF EXISTS {$wpdb->$table}");

// add_filter('admin_menu', 'admin_menu_filter',500);
// function admin_menu_filter(){
//     remove_submenu_page( 'crud.php', 'crudDataList.php' );//widget
// }

}
?>