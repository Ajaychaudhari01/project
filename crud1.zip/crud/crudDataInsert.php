
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- CSS only -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<! -- jquery link for validatiion --->
	<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
	<!--------- for show password jquery link  ------------->
	<style type="text/css">
		.error {
			color: red;
			background-color: #010111;
		}
		
		body {
			background-image: url("3.jpg");
			background-repeat: no-repeat;
			background-color: #cccccc;
		}

	</style>
</head>
<body>



</body>
</html>


<?php
/**
Use these line of codes, its working more than 100%
 */
//get_header();?> 
<?php
if (!empty($_POST)) {
	global $wpdb;

	global $table_prefix;
	$table = $table_prefix.'Crud_data';

	$data = array(
		'id' =>$_POST['id'],
		'username' => $_POST['username'],
		'email'    => $_POST['email'],
		'password' => $_POST['password'],
		'phone'    => $_POST['phone']
	);
	$format = array(
		'%s',
		'%s'
	);
	$success=$wpdb->insert( $table, $data, $format );
	if($success){
		$url = admin_url('admin.php?page=crud');
		echo "<script>window.location.href='$url';</script>";

	}
}
else   {
	?>

	<h1 class="bg-dark text-white mt-2">Welcome <span class="text-danger"></span> Here you can add any user details....</h1>
	<section>
		<div class="container">
			<div class="row mt-5">
				<div class="col-md-3" mt-5></div>
				<div class="col-md-6  mt-5">
					
					<form method="post" id="addUser">
						<div class="form-group">
							<label for="exampleFormControlInput1">UserName</label>
							<input type="text" class="form-control" id="txtLogin" name="username" placeholder="xyz">
						</div>

						<div class="form-group">
							<label for="exampleFormControlInput1">Email address</label>
							<input type="email" class="form-control" name="email" placeholder="name@example.com">
						</div>

						<div class="form-group">
							<label for="exampleFormControlInput1">Password </label>
							<input type="password" class="form-control" name="password" placeholder="Virat@773">
						</div>

						<div class="form-group">
							<label for="exampleFormControlInput1">Phone </label>
							<input type="number" class="form-control" name="phone" placeholder="58585855858">
						</div>
						
						<button type="submit" name="submit" class="btn btn-primary btn-block">Add User</button>
					</form>
				</div>
				<div class="col-md-3"></div>
			</div>
		</div>
	</div>
</section>



<?php }  ?>


<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
<script>
    //javascript validation
    $(document).ready(function() {
    	$("#addUser").validate({
    		errorClass: "error fail-alert",
    		validClass: "valid success-alert",
    		rules: {
    			username : {
    				required: true,
    				minlength: 3,
    				maxlength: 15

    			},
    			password: {
    				required: true,
    				minlength: 3,
    				maxlength: 15
    			},
    			phone: {
    				required: true,
    				minlength: 10,
    				maxlength: 13
    			},

    			email: {
    				required: true,
    				email: true
    			},
    		},
    		messages : {
    			username: {
    				minlength: "Name should be at least 3 characters",
    				maxlength: "Name should not be at greater than 15 characters"

    			},
    			password: {
    				required: "Please enter your password",
    				minlength: "Password should be at least 3 characters",
    				maxlength: "Password should not be at greater than 15 characters"
    			},
    			mobile: {
    				minlength: "Mobile number should be at least 10 characters",
    				maxlength: "Mobile number should not be at greater than 13 characters"
    			},

    			email: {
    				email: "The email should be in the format: abc@domain.tld"
    			},
    		}
    	});
      //

//for disabling space entery in input fields......
$('input').keypress(function( e ) {
	if(e.which === 32) 
		return false;
});


});

</script>



