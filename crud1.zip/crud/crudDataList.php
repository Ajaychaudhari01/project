<?php 


global $wpdb;
global $table_prefix;
$table = $table_prefix.'Crud_data';
$sql= "select * from $table";
$result=$wpdb->get_results($sql);
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>

	<!-- Font Awesome -->
	<link
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
	rel="stylesheet"
	/>
	<!-- Google Fonts -->
	<link
	href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
	rel="stylesheet"
	/>
	<!-- MDB -->
	<link
	href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.0.0/mdb.min.css"
	rel="stylesheet"
	/>
	<!-- JavaScript Bundle with Popper -->
	<style type="text/css">
		
		body {
			background-image: url("3.jpg");
			background-repeat: no-repeat;
			background-color: #cccccc;
		}

	</style>
</head>
<body>



	<div class="section">
		<div class="container">
			<table class="table">
				<thead>
					<tr>
						<th scope="col">#</th>
						<th scope="col">Username</th>
						<th scope="col">Email</th>
						<th scope="col">Phone</th>
						<th scope="col">
							
							<button type="button" class="btn btn-success btn-lg" name="delete">  
								<a class="dropdown-item" href="admin.php?page=Insert">Add User</a>
							</button>
						</th>
						

					</tr>
				</thead>
				<tbody>
					<?php 
					foreach ($result as $List) { ?> 	
						<tr>
							<th scope="row"><?php echo $List->id ;?></th>
							<td ><?php echo $List->username ;?></td>
							<td ><?php echo $List->email ;?></td>
							<td ><?php echo $List->phone ;?></td>
							<td >       
								<button type="button" class="btn btn-danger btn-del btn-sm" name="delete">  
									<a class="dropdown-item" href="admin.php?page=Delete&action=Delete&id=<?php echo $List->id ;?>">Delete</a>
								</button>
								<button type="button" class="btn btn-primary btn-sm" name="Update">  
									<a class="dropdown-item" href="admin.php?page=Update&action=Update&id=<?php echo $List->id ;?>">Edit</a>
								</button>

							</td>
						</tr>
					<?php } ?>
				</tbody>
			</table>

		</div>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
		<script src="jquery-3.6.0.min.js"></script>

	</body>
	</html>