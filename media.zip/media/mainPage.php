<?php

session_start();


?>




<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- Font Awesome -->
	<link
	href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
	rel="stylesheet"
	/>
	<!-- Google Fonts -->
	<link
	href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
	rel="stylesheet"
	/>
	<!-- MDB -->
	<link
	href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.0.0/mdb.min.css"
	rel="stylesheet"
	/>
</head>
<body>


<section class="mt-5">
	<div class="container m-3">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				
				<!-- Pills navs -->
				<ul class="nav nav-pills nav-justified mb-3" id="ex1" role="tablist">
					<li class="nav-item" role="presentation">
						<a
						class="nav-link active"
						id="tab-login"
						data-mdb-toggle="pill"
						href="#pills-login"
						role="tab"
						aria-controls="pills-login"
						aria-selected="true"
						>Login</a
						>
					</li>
					<li class="nav-item" role="presentation">
						<a
						class="nav-link"
						id="tab-register"
						data-mdb-toggle="pill"
						href="#pills-register"
						role="tab"
						aria-controls="pills-register"
						aria-selected="false"
						>Register</a
						>
					</li>
				</ul>
				<!-- Pills navs -->

				<!-- Pills content -->
				<div class="tab-content">
					<div class="tab-pane fade show active" id="pills-login" role="tabpanel" aria-labelledby="tab-login">
						<form method="post" action="http://localhost/demo/wp-admin/admin.php?page=dash" id="myForm">
							<!-- Email input -->
							<div class="form-outline mb-4">
								<input type="text" name="username" id="username" class="form-control" />
								<label class="form-label" for="loginName">Email or username</label>
							</div>

							<!-- Password input -->
							<div class="form-outline mb-4">
								<input type="password" name="password" id="password" class="form-control" />
								<label class="form-label" for="loginPassword">Password</label>
							</div>
							<!-- Submit button -->
							<button type="submit"  name="login" id="loginbtn"  class="btn btn-primary btn-block mb-4">Sign in</button>

						</form>
					</div>




					<div class="tab-pane fade" id="pills-register" role="tabpanel" aria-labelledby="tab-register">
						<form method="post" enctype="multipart/form-data">
							<!-- Username input -->
							<div class="form-outline mb-1">
								<input type="text" name="username" class="form-control" />
								<label class="form-label" for="registerUsername">Username</label>
							</div>
							<!-- Name input -->
							<div class="form-outline mb-1">
								<input type="text" name="fname" class="form-control" />
								<label class="form-label" for="registerName">FirstName</label>
							</div>
							<!-- Name input -->
							<div class="form-outline mb-1">
								<input type="text" name="lname" class="form-control" />
								<label class="form-label" for="registerName">LastName</label>
							</div>

							<!-- Email input -->
							<div class="form-outline mb-1">
								<input type="email" name="email" class="form-control" />
								<label class="form-label" for="registerEmail">Email</label>
							</div>

							<!-- Password input -->
							<div class="form-outline mb-1">
								<input type="password" name="password" class="form-control" />
								<label class="form-label" for="registerPassword">Password</label>
							</div>

							<!-- Repeat Password input -->
							<div class="form-outline mb-1">
								<input type="password" name="registerRepeatPassword" class="form-control" />
								<label class="form-label" for="registerRepeatPassword">Repeat password</label>
							</div>

							<!-- image input -->
							<div class="form-outline mb-1">
								<input type="file" name="uploadfile" id="uploadfile" class="form-control" />
								<label class="form-label" for="registerRepeatPassword"></label>
							</div>

							<!-- Dateinput -->
							<div class="form-outline mb-1">
								<input type="date" name="dob" class="form-control" />
								<label class="form-label" for="registerRepeatPassword">DOB</label>
							</div>

							<!-- Phone input -->
							<div class="form-outline mb-1">
								<input type="number" name="phone" class="form-control" />
								<label class="form-label" for="registerRepeatPassword">Phone</label>
							</div>

							<!-- Submit button -->
							<button type="btn" name="register" class="btn btn-primary btn-block mb-3">Sign in</button>
						</form>
					</div>
				</div>
				<!-- Pills content -->
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>

</section>


<!-- MDB -->
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.0.0/mdb.min.js"
></script>

<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
</body>
</html>


<?php
if(isset($_POST['register'])){

  global $wpdb;
  global $table_prefix;
  $table = $table_prefix.'people';
	$username = $_POST['username'];
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$dob = $_POST['dob'];
	$phone = $_POST['phone'];

  // file uploding code
  $filename = $_FILES["uploadfile"]["name"];
  $tempname = $_FILES["uploadfile"]["tmp_name"];  
  $folder = "image/".$filename;

    // Now let's move the uploaded image into the folder: image
  if (move_uploaded_file($tempname, $folder)) {
    $msg = "Image uploaded successfully";
  }else{
    $msg = "Failed to upload image";
  }


	$sql= $wpdb->prepare("insert into $table (username,fname,lname,email,password,dob,mobile,images)
	 values('$username','$fname','$lname','$email','$password','$dob','$phone','$filename')");
	$result = $wpdb->query($sql);
	if($result){
		echo "thanks brohter";
	}else{
		echo "kya dekh rha hai re cc";
	}

}


// if(isset($_POST['login'])){

//   global $wpdb;
//   global $table_prefix;
//   $table = $table_prefix.'people';
// 	$username = $_POST['loginName'];
// 	$password = $_POST['loginPassword'];

// 	$sql= $wpdb->prepare("select * from $table where username='$username' && password='$password'");
// 	$result = $wpdb->query($sql);
// 	if($result){
		
// 				$url = admin_url('admin.php?page=dash');
// 		echo "<script>window.location.href='$url';</script>";

// 		$_SESSION['username'] = $_POST['loginName'];
// 				echo $_SESSION['username'];
// 		$_SESSION['password'] = $password;
// 	}else{
// 		echo "bhkk";
// 	}

// }


?>
<script type="text/javascript">


// $("#loginbtn").click(function(){

// console.log("button clicked");
// let name=$("#username").val();
// let password=$("#password").val();
// console.log(name);
// console.log(password);
// mydata={ name:name, password:password};
// console.log(mydata);
// $.ajax({
// 	url:"userList.php",
// 	method:"POST",
// 	data:JSON.stringify(mydata),
// 	success:function(data){
// 		//console.log(data);
// 	},
// });
// });

$('document').ready(function () {
	$('#loginbtn').click(function() {
		$.post('userList.php',$('#myForm').serialize(),function (data) {
			console.log(data);
		})
	});
})
</script>