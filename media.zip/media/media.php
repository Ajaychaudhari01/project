<?php
/*
Plugin Name: Blog
Plugin URI: https://github.com/Ajaychaudhari01/
Description: Just another Blog  plugin. Simple but flexible.
Author: Ajay Chaudhari
Author URI : https://github.com/Ajaychaudhari01/
Version: 1.0
*/

//link for custom curd opertions in wordpress........
//https://phpcoder.tech/how-to-create-plugin-in-wordpress-with-example/
// hook for pulgin activate/ deactivate


register_activation_hook(__FILE__,'hook_activation');
register_deactivation_hook(__FILE__,'hook_deactivation');


function hook_activation()
{
	global $wpdb;
	global $table_prefix;
	$table=$table_prefix.'people';
	$sql="CREATE TABLE $table (
	id int NOT NULL AUTO_INCREMENT,
	username varchar(255) NOT NULL,
 fname varchar(255) NOT NULL,
  lname varchar(255) NOT NULL,
  email varchar(255) NOT NULL,
  mobile int(20) NOT NULL,
  password varchar(255) NOT NULL,
  picture varchar(255) NOT NULL,
  dob date NOT NULL,
  hobbies varchar(255) NOT NULL,
  gender varchar(255) NOT NULL,
  country varchar(255) NOT NULL,
	PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;";

$wpdb->query($sql);

}




function hook_deactivation()
{
	//code
}

add_action('admin_menu','blog_menu');

function blog_menu(){
	add_menu_page('list', //page title
        'ChitChat', //menu title
        'manage_options', //capabilities
        'blog', //menu slug
        user_auth_page //function
    );
    add_submenu_page('blog',//parent page slug
        'Dashboard',//page title
        'Dashboard',//menu titel
        'manage_options',//manage optios
        'dash',//slug
        User_dashBoard//function
    );
    add_submenu_page('blog',//parent page slug
        'test',//page title
        'test',//menu titel
        'manage_options',//manage optios
        'test',//slug
        User_test//function
    );
}

function user_auth_page(){
	include('mainPage.php');
}

function User_dashBoard(){
	include('userList.php');
}
function User_test()
{
  include('test.php');
}
?>
