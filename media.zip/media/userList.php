<?php

$username = $_POST['username'];


// $data=stripslashes(file_get_contents("php://input"));
// // $mydata=json_decode($data,true);
// // $password=$mydata['password'];
// echo $mydata;


//  session_start();
// echo $_SESSION['username'];
// echo "hii";
// echo "hello";
// global $wpdb;
// global $table_prefix;
// $table=$table_prefix.'people';
// // if (isset($_SESSION['username']) && isset($_SESSION['password'])) {
// // 	$username=$_SESSION['username'];
// 	$username = 'abdul';
// 	$sql= $wpdb->prepare("select * from $table where username='$username'");
// 	$result = $wpdb->get_results($sql);
// 	$r=mysqli_fetch_assoc($result);
// 	print_r($result);
// $array = json_encode($result);
// 	print_r($array);
// 	echo $array['email'];
// 	if($result==TRUE)
// 	{ 	echo $r['fname'];

// 		echo "successfully fetch ";

// 	} 
// 	else
// 	{
// 		echo "ohh sorry !!!";
// 	}

// // }
// // else
// // {
// // 	echo $_SESSION['username'];
// // 	echo "Session expire ";

// // }

// session_start();






global $wpdb;
global $table_prefix;
$table = $table_prefix.'people';
$qry= "select * from `wp_people` where username='$username'";
$res=$wpdb->prepare($qry);
$result= $wpdb->get_results($res);
$array = json_decode(json_encode($result), true);
foreach ($array as $ar) { ?>

	<!DOCTYPE html>
	<html>
	<head>
		<title></title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<!-- Font Awesome -->
		<link
		href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
		rel="stylesheet"
		/>
		<!-- Google Fonts -->
		<link
		href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
		rel="stylesheet"
		/>
		<!-- MDB -->
		<link
		href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.0.0/mdb.min.css"
		rel="stylesheet"
		/>
	</head>
	<body>

		<!-- Navbar-->
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<div class="container-fluid justify-content-between">
				<!-- Left elements -->
				<div class="d-flex">
					<!-- Brand -->
					<a class="navbar-brand me-2 mb-1 d-flex align-items-center" href="#">
						<img
						src="https://mdbcdn.b-cdn.net/img/logo/mdb-transaprent-noshadows.webp"
						height="20"
						alt="MDB Logo"
						loading="lazy"
						style="margin-top: 2px;"
						/>
					</a>

					<!-- Search form -->
					<form class="input-group w-auto my-auto d-none d-sm-flex " method="post">

						<span class="input-group-text border-0 d-none d-lg-flex"  type="submit">
							<input id="search" name="search" type="search" placeholder="Type here" >
							<a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample"> search  </a>
						</span>

					</form>
				</div>
				<!-- Left elements -->

				<!-- Center elements -->
				<ul class="navbar-nav flex-row d-none d-md-flex">
					<li class="nav-item me-3 me-lg-1 active">
						<a class="nav-link" href="#">
							<span><i class="fas fa-home fa-lg"></i></span>
							<span class="badge rounded-pill badge-notification bg-danger">1</span>
						</a>
					</li>


					<li class="nav-item me-3 me-lg-1">
						<a class="nav-link" data-mdb-toggle="modal" data-mdb-target="#friendRequest" href="#">
							<span><i class="fas fa-users fa-lg"></i></span>
							<span class="badge rounded-pill badge-notification bg-danger">2</span>
						</a>
					</li>
				</ul>
				<!-- Center elements -->

				<!-- Right elements -->
				<ul class="navbar-nav flex-row">
					<li class="nav-item me-3 me-lg-1">
						<a class="nav-link d-sm-flex align-items-sm-center" data-toggle="collapse" href="#profile" role="button" aria-expanded="false" aria-controls="profile">
							<img
							src="https://mdbcdn.b-cdn.net/img/new/avatars/1.webp"
							class="rounded-circle"
							height="22"
							alt=""
							loading="lazy"
							/>
							<strong class="d-none d-sm-block ms-1"><span >Welcome </span><?php echo $ar['username']?></strong>
						</a>

					</li>
					<li class="nav-item me-3 me-lg-1">
						<a class="nav-link" href="#">
							<span><i class="fas fa-plus-circle fa-lg"></i></span>
						</a>
					</li>
					<li class="nav-item dropdown me-3 me-lg-1">
						<a
						class="nav-link dropdown-toggle hidden-arrow"
						href="#"
						id="navbarDropdownMenuLink"
						role="button"
						data-mdb-toggle="dropdown"
						aria-expanded="false"
						>
						<i class="fas fa-comments fa-lg"></i>

						<span class="badge rounded-pill badge-notification bg-danger">6</span>
					</a>
					<ul
					class="dropdown-menu dropdown-menu-end"
					aria-labelledby="navbarDropdownMenuLink"
					>
					<li>
						<a class="dropdown-item" href="#">Some news</a>
					</li>
					<li>
						<a class="dropdown-item" href="#">Another news</a>
					</li>
					<li>
						<a class="dropdown-item" href="#">Something else here</a>
					</li>
				</ul>
			</li>
		</ul>
		<!-- Right elements -->
	</div>
</nav>
<!-- Navbar -->
<?php }?>


<!-- search friend started here  -->

<div class="collapse" id="collapseExample">
	<div class="card card-body">
		<table class="table align-middle mt-5 mb-0 bg-white">
			<tbody>
				<?php								
										//searchbar start
				global $wpdb;
				$username = $_POST['search'];
				$qry= "select * from `wp_people` where username='$username'";
				$res=$wpdb->prepare($qry);
				$result= $wpdb->get_results($res);
				$array = json_decode(json_encode($result), true);
				foreach ($array as $arr ) { ?>
					<tr>
						<td>
							<div class="d-flex align-items-center">
								<img src="https://mdbootstrap.com/img/new/avatars/8.jpg" alt=""
								style="width: 45px; height: 45px"
								class="rounded-circle"/>
								<div class="ms-3">
									<p class="fw-bold mb-1"><?php echo $ar['username'] ; ?></p>
								</div>
							</div>
						</td>
						<td>
							<button type="button" class="btn btn-link btn-sm btn-rounded bg-success text-center text-white">
								Send Request
							</button>
						</td>
						<td>
							<button type="button" class="btn btn-link btn-sm btn-rounded bg-success text-center text-white">
								Cancel
							</button>
						</td>
					</tr>
				<?php } ?>
			</tbody>
		</table>

	</div>
</div>


<div class="collapse" id="profile">

	<section>
		<div class="container-fluid">
			<div class="row mt-5">
				<h1 class="text-center">Welcome !!</h1>
				<div class="col-md-4 bg-success">
					<table class="table align-middle mb-0 bg-white">
						<thead class="bg-light">
							<tr>
								<td>
									<div class="d-flex align-items-center">
										<img
										src="<?php echo $ar['images']?>"
										alt="sorry "
										style="width: 100px; height: 100px"
										class="rounded-circle"
										/>
										<div class="ms-3">
											<p class="fw-bold mb-1"><?php echo $ar['username']?></p>
											<p class="text-muted mb-0"><?php echo $ar['email']?></p>
										</div>
									</div>
								</td>

							</tr>
						</thead>
					</table>

				</div>
				<div class="col-md-8 bg-danger">
					<table class="table align-middle mb-0 bg-white">
						<thead class="bg-light">
							<tr>
								<th>Username</th>
								<th><?php echo $ar['username']?></th>
							</tr>
						</tr>
						<tr>
							<th>First Name</th>
							<th><?php echo $ar['fname']?></th>
						</tr>
						<tr>
							<th>Last Name</th>
							<th><?php echo $ar['lname']?></th>
						</tr>
						<tr>
							<th>Email</th>
							<th><?php echo $ar['email']?></th>
						</tr>
						<tr>
							<th>DOb</th>
							<th><?php echo $ar['dob']?></th>
						</tr>
						<tr>
							<th>Phone</th>
							<th><?php echo $ar['mobile']?></th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>
</section>

</div>


<!-- Mdb modal for friend request list start   -->
<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="friendRequest" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
				<button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
			</div>
			<div class="modal-body">
				<table class="table align-middle mt-5 mb-0 bg-white">
					<tbody>
						<tr>
							<td>
								<div class="d-flex align-items-center">
									<img src="https://mdbootstrap.com/img/new/avatars/8.jpg" alt=""
									style="width: 45px; height: 45px"
									class="rounded-circle"/>
									<div class="ms-3">
										<p class="fw-bold mb-1">John Doe</p>
									</div>
								</div>
							</td>
							<td>
								<button type="button" class="btn btn-link btn-sm btn-rounded bg-success text-center text-white">
									Confirm
								</button>
							</td>
							<td>
								<button type="button" class="btn btn-link btn-sm btn-rounded bg-success text-center text-white">
									Cancel
								</button>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary">Save changes</button>
			</div>
		</div>
	</div>
</div>


<!-- Mdb modal for friend request list  end-->

<div class="collapse" id="cratePost">
	<div class="card card-body">
		<form method="post" action="http://localhost/demo/wp-admin/admin.php?page=dash" id="myForm" enctype="multipart/form-data">
			<!-- Email input -->
			
				<!-- Password input -->
			<div class="form-outline mb-4">
				<input type="text" name="caption" id="caption" class="form-control" />
				<label class="form-label" for="caption">Caption</label>
			</div>
			<div class="form-outline mb-4">
				<input type="file" name="img" id="img" class="form-control" placeholder="Upload your image" />
			</div>
			<!-- Password input -->
			<div class="form-outline mb-4">
				<input type="text" name="tags" id="tags" class="form-control" />
				<label class="form-label" for="tags">Tags</label>
			</div>
			<!-- Submit button -->
			<button type="submit"  name="cratePostbtn" id="cratePostbtn"  class="btn btn-primary btn-block mb-4">Post</button>

		</form>
	</div>
</div>


<section>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-4">
				<div class="mt-5">
					<a class="btn btn-primary" data-toggle="collapse" href="#cratePost" role="button" aria-expanded="false" aria-controls="cratePost">
						Add a Post
					</a>
				</div>
			</div>
			<div class="col-md-8">

<section>
		<div class="container-fluid"> 
							<?php

													//this is user post show code 
						//this is user post show code 
						global $wpdb;
						$postQry= "select * from post";
						$postRes=$wpdb->prepare($postQry);
						$postRsult= $wpdb->get_results($postRes);
						$postArray = json_decode(json_encode($postRsult), true);
						foreach ($postArray as $postAr) { ?>

			<div class="row mt-5">
					<table class="table align-middle mb-0 bg-white">
						<thead class="bg-light">
							<tr>
								<td>
									<div class="d-flex align-items-center">
										<img src="image/<?php echo $postAr['image']?>" alt="sorry " style="width: 100px; height: 100px"
										class="rounded-circle"
										/>
										<div class="ms-3">
											<p class="fw-bold mb-1"><?php echo $postAr['tags']?></p>
											<p class="text-muted mb-0"><?php echo $postAr['captions']?></p>
										</div>
									</div>
								</td>

							</tr>
						</thead>
					</table>
				</div>
			<?php }?>
	</div>
</section>



			</div>
		</div>
	</div>
</section>






<!-- MDB -->
<script
type="text/javascript"
src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/4.0.0/mdb.min.js"
></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
</body>
</html>


<?php
if(isset($_POST['cratePostbtn'])){

  global $wpdb;
	$iamges = $_POST['img'];
	$caption = $_POST['caption'];
	$tags = $_POST['tags'];

  // file uploding code
  $filename = $_FILES["img"]["name"];
  $tempname = $_FILES["img"]["tmp_name"];  
  $folder = "image/".$filename;

    // Now let's move the uploaded image into the folder: image
  if (move_uploaded_file($tempname, $folder)) {
    $msg = "Image uploaded successfully";
  }else{
    $msg = "Failed to upload image";
  }


	$sql= $wpdb->prepare("insert into post (image,captions ,tags)values('$filename','$caption','$tags')");
	$result = $wpdb->query($sql);
	print_r($result);
	if($result){
		echo "thank  u your post is created ";
	}else{
		echo "ss sooryy !!";
	}

}
else{
	//echo "sorry failure due to form data";
}







?>