$.validator.setDefaults( {
    submitHandler: function () {
        alert( "Form Submitted Successfully" );
    }
});


$('#register-form').validate({
    rules : {
        firstname : {
            required: true,
            minlength: 3
        },

        email : {
            required: true,
            email: true
        },
        mobile : {
            required: true,
            mobile: true
        },
        select : {
            required: true
        },
        about : {
            required: true
        },
        terms : {
            required: true
        }
    },
    messages : {
        firstname : {
            required: 'Please Enter a first name',
            minlength: 'Enter at least 3 letters for first name'
        },

        email : {
            required: 'Please Enter an email',
            email: 'Enter a Proper Email'
        },
        mobile : {
            required: 'Please Enter an mobile',
            mobile: 'Enter a Proper mobile number '
        },

        select : {
            required: 'Please select a mov=bile model ',
        },
        about : {
            required: 'Please Say About yourself ',
        },
        terms : {
            required: 'Please Accepts the Terms & Conditions'
        }
    },
    errorPlacement: function ( error, element ) {
        // Add the `invalid-feedback` class to the error element
        error.addClass( "invalid-feedback" );

        if ( element.prop( "type" ) === "checkbox" ) {
            error.insertAfter( element.next( "label" ) );
        } else {
            error.insertAfter( element );
        }
    },
    highlight: function ( element, errorClass, validClass ) {
        $( element ).addClass( "is-invalid" ).removeClass( "is-valid" );
    },
    unhighlight: function (element, errorClass, validClass) {
        $( element ).addClass( "is-valid" ).removeClass( "is-invalid" );
    }
});